# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class DataItem(scrapy.Item):
    # define the fields for your item here like:
    item_id = scrapy.Field()
    url = scrapy.Field()
    name = scrapy.Field()
    brand = scrapy.Field()
    price = scrapy.Field()
    finalprice = scrapy.Field()
    estimatedrealprice = scrapy.Field()
    currency = scrapy.Field()
    model = scrapy.Field()
    modelNo = scrapy.Field()
    gender = scrapy.Field()
    year = scrapy.Field()
    condition = scrapy.Field()
    images = scrapy.Field()
    description = scrapy.Field()
    box = scrapy.Field()
    papers = scrapy.Field()
    caseSize = scrapy.Field()
    caseMaterial = scrapy.Field()
    caseShape = scrapy.Field()
    dailColor = scrapy.Field()
    movement = scrapy.Field()
    bandcolor = scrapy.Field()
    braceleMatrial = scrapy.Field()
    waterResistance = scrapy.Field()
    details = scrapy.Field()
    fetchDate = scrapy.Field()
    pass
