import  scrapy
from ..items import DataItem
from scrapy.selector import Selector
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium import webdriver
from bs4 import BeautifulSoup
from datetime import datetime

class MadhuScrapy(scrapy.Spider):
    name='madhu'
    start_urls=[
        'https://www.thewatchbox.com/',
        'https://www.thewatchbox.com/watches/rolex',
        'https://www.thewatchbox.com/watches/rolex/submariner/rolex-submariner-116610ln'
    ]
    def parse(self,response):
        items =DataItem()
        description = response.css('.tab-content div.tab-pane.active #description').get()

        details_tab = response.css('.tab-content div.tab-pane.active #details')
        box = details_tab.css('li:contains("Box")::text').get()
        papers = details_tab.css('li:contains("Papers")::text').get()

        driver = webdriver.Chrome()
        driver.get('https://www.thewatchbox.com/')

        item_id = response.xpath("//dt[contains(text(), 'SKU')]/following-sibling::dd/text()").get()

        product_code = response.css(".product-details .breadcrumb span:last-child::text").get()
        product_url = response.url
        breadcrumbs = response.css(".breadcrumb li::text").getall()
        price_element = response.css(".actual-price .price::text").get()
        price = price_element.split()[0]

        currency = price_element.split('')[1]

        retail_price_element = response.xpath(
            "//strong[contains(text(),'Retail Price')]/following-sibling::text()").get().strip()
        retail_price = retail_price_element.split()[0] if 'Discontinued' not in retail_price_element else None
        final_price = product_url.find_element_by_css_selector('.primary-price').text
        breadcrumbs = product_url.find_elements_by_css_selector('.breadcrumb a')
        brand = breadcrumbs[1].text.strip()
        model = breadcrumbs[2].text.strip()
        modelNo = product_url.find_element_by_css_selector('#stock_model').text.strip()

        drive=product_url.implicitly_wait(10)
        gender = Selector(text=drive.page_source).css('.gender-selector ::text').get()
        year = Selector(text=drive.page_source).css('.year-selector ::text').get()
        slideshow = WebDriverWait(driver, 10).until(
            EC.visibility_of_element_located((By.CLASS_NAME, 'slideshow'))
        )

        image_elements = slideshow.find_elements_by_tag_name('img')

        image_urls = [img.get_attribute('src') for img in image_elements]
        case_material = response.css(
            'div.watch-details div.watch-details__description:contains("Case Material") + div.watch-details__value::text').get()
        soup = BeautifulSoup(driver.page_source, 'html.parser')

        product_name = soup.select('.pdp-name')[0].text.strip()

        brand_name = soup.select('.pdp-name span')[0].text.strip()
        breadcrumbs = [breadcrumb.text.strip() for breadcrumb in soup.select('#stock_series li')]

        model_number = soup.select('#stock_model')[0].text.strip()

        gender = soup.select('#gender')[0].text.strip()
        year = soup.select('#year')[0].text.strip()

        price = soup.select('.product__price__value')[0].text.strip()
        final_price = soup.select('.product__final-price__value')[0].text.strip()

        condition = soup.select('meta[itemprop="itemCondition"]')[0]['content']
        images = [image['src'] for image in soup.select('.product__slideshow__thumbs img')]

        description = soup.select('.pdp-about')[0].text.strip()
        box = soup.select('#stock_box')[0].text.strip()
        papers = soup.select('#stock_papers')[0].text.strip()

        case_size = soup.select('#stock_case_size')[0].text.strip()
        case_material = soup.select('#stock_case_material')[0].text.strip()

        dial_color = soup.select('#stock_dial_color')[0].text.strip()
        dial_type = soup.select('#stock_dial_type')[0].text.strip()

        movement = soup.select('#stock_movement')[0].text.strip()
        band_color = soup.select('#stock_band_color')[0].text.strip()
        bracelet_material = soup.select('#stock_bracelet_material')[0].text.strip()

        water_resistance = soup.select('#stock_water_resistance')[0].text.strip()

        details = {}
        for detail in soup.select('.pdp-right__features__feature'):
            key = detail.select('.pdp-right__features__feature__title')[0].text.strip()
            value = detail.select('.pdp-right__features__feature__value')[0].text.strip()
            details[key] = value
        fetch_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        items['item_id']=item_id
        items['url']=product_url
        items['name']=breadcrumbs
        items['brand']=brand_name
        items['price']=price
        items['finalprice']=final_price
        items['estimatedrealprice']=retail_price_element
        items['currency']=retail_price
        items['model']=model
        items['modelNo']=modelNo
        items['gender']=gender
        items['year']=year
        items['condition']= condition
        items['images']=images
        items['description']=description
        items['box']=box
        items['papers']=papers
        items['caseSize']=case_size
        items['caseMaterial']=case_material
        items['caseShape']=case_size
        items['dailColor']=dial_color
        items['movement']=movement
        items['bandcolor']=band_color
        items['braceleMatrial']=bracelet_material
        items['waterResistance']=water_resistance
        items['details']=details
        items['fetchDate']=fetch_date
        yield  items